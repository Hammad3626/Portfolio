document.addEventListener('DOMContentLoaded', () => {
  // 🔒 Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    sessionStorage.removeItem('currentUser');
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
  });

  // 📦 Load shared inventory from localStorage
  const INVENTORY = JSON.parse(localStorage.getItem('inventory') || '[]');

  const el = sel => document.querySelector(sel);
  const grid = el('#itemsGrid');
  let bill = [];  // Current order
  const billBody = el('#billTable tbody');
  const grandTotalCell = el('#grandTotal');

  // 🧾 Build clickable item cards
  INVENTORY.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item-card';
    div.innerHTML = `
      <img src="${item.img}" alt="${item.item}">
      <strong>${item.item}</strong>
      <small>${item.price.toFixed(2)} €</small>
    `;
    div.addEventListener('click', () => addToBill(item));
    grid.appendChild(div);
  });

  function addToBill(item) {
    const existing = bill.find(b => b.item === item.item);
    if (existing) existing.qty++;
    else bill.push({...item, qty: 1});
    renderBill();
  }

  function renderBill() {
    billBody.innerHTML = '';
    let total = 0;

    bill.forEach((row, i) => {
      const line = row.price * row.qty;
      total += line;
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${row.cat || row.category}</td>
        <td>${row.item}</td>
        <td>${row.price.toFixed(2)}</td>
        <td><input type="number" min="1" value="${row.qty}" data-idx="${i}"></td>
        <td>${line.toFixed(2)}</td>
        <td><button data-del="${i}">✖</button></td>
      `;
      billBody.appendChild(tr);
    });

    grandTotalCell.textContent = total.toFixed(2);

    billBody.querySelectorAll('input').forEach(inp =>
      inp.onchange = () => {
        const idx = +inp.dataset.idx;
        bill[idx].qty = Math.max(1, +inp.value);
        renderBill();
      });

    billBody.querySelectorAll('button[data-del]').forEach(btn =>
      btn.onclick = () => {
        bill.splice(+btn.dataset.del, 1);
        renderBill();
      });
  }

  // 🖨️ Print & Save Invoice
  el('#printBtn').addEventListener('click', () => {
    if (!bill.length) return alert('Add items first.');

    const stamp = new Date().toLocaleString('en-GB');
    const invoice = {
      id: Date.now(),
      date: new Date().toISOString(), // or .toLocaleString('en-GB')
      items: [...bill],
      total: +grandTotalCell.textContent
    };

    // Save invoice to history
    const history = JSON.parse(localStorage.getItem("invoices") || "[]");
    history.push(invoice);
    localStorage.setItem("invoices", JSON.stringify(history));

    // ⬇️ Update inventory: increase `sales` count
    const currentInventory = JSON.parse(localStorage.getItem("inventory") || "[]");
    bill.forEach(orderItem => {
      const match = currentInventory.find(inv =>
        (inv.item === orderItem.item) && 
        ((inv.cat || inv.category) === (orderItem.cat || orderItem.category))
      );
      if (match) {
        match.sales = (match.sales || 0) + orderItem.qty;
      }
    });
    localStorage.setItem("inventory", JSON.stringify(currentInventory));

    // 🖨 Print invoice (2 copies)
    const html = makeInvoiceHTML(bill, stamp);
    el('#printContainer').innerHTML = `<div class="copy">${html}</div><div class="copy">${html}</div>`;
    window.print();

    bill = [];
    renderBill();
  });

  function makeInvoiceHTML(bill, stamp) {
    const rows = bill.map(r => `
      <tr>
        <td>${r.cat || r.category}</td>
        <td>${r.item}</td>
        <td>${r.qty}</td>
        <td>${r.price.toFixed(2)}</td>
        <td>${(r.qty * r.price).toFixed(2)}</td>
      </tr>`).join('');

    const total = bill.reduce((sum, r) => sum + r.qty * r.price, 0).toFixed(2);

    return `
      <h1 style="text-align:center;">Snack Speed</h1>
      <table class="bill-table" style="width:100%;margin-top:1rem;">
        <thead><tr><th>Cat.</th><th>Item</th><th>Qty</th><th>€ Unit</th><th>€ Line</th></tr></thead>
        <tbody>${rows}</tbody>
        <tfoot><tr><th colspan="4">TOTAL</th><th>${total}</th></tr></tfoot>
      </table>
      <p style="margin-top:1rem;">Date/Time: ${stamp}</p>
      <p style="margin-top:2rem;font-size:.9rem;">
        CIF: 40980591‑L<br>
        Av. Catalunya nº5 · 43002 Tarragona
      </p>
      <hr style="margin:2rem 0;">
    `;
  }

  // 📜 Show Invoice History
  el('#historyBtn').onclick = () => {
    const list = JSON.parse(localStorage.getItem('invoices') || '[]');
    const tbody = el('#historyTable tbody');
    tbody.innerHTML = '';
    list.forEach((inv, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${i + 1}</td>
        <td>${inv.date}</td>
        <td>${inv.items.map(b => `${b.qty}× ${b.item}`).join(', ')}</td>
        <td>${inv.total.toFixed(2)}</td>
      `;
      tbody.appendChild(tr);
    });
    el('#historyModal').style.display = 'flex';
  };

});
