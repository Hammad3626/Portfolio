document.addEventListener('DOMContentLoaded', () => {
  const LS = {
    get: k => JSON.parse(localStorage.getItem(k) || 'null'),
    set: (k, v) => localStorage.setItem(k, JSON.stringify(v))
  };
  const SS = {
    del: k => sessionStorage.removeItem(k)
  };

  const me = LS.get('currentUser') || JSON.parse(sessionStorage.getItem('currentUser') || 'null');
  if (!me || me.role !== 'owner') {
    window.location.href = 'login.html';
    return;
  }

  const invBody = document.querySelector('#inventoryTable tbody');
  const invForm = document.querySelector('#inventoryForm');
  const invId   = document.getElementById('invId');

  // Seed initial inventory if missing
  if (!LS.get('inventory')) {
    LS.set('inventory', [
      { category: 'CAFÉS', item: 'Café solo',      price: 1.20, sales: 0, img: 'CDS/cafe-solo.jpeg' },
      { category: 'CAFÉS', item: 'Café cortado',   price: 1.40, sales: 0, img: 'CDS/cafe-cortado.jpeg' },
      { category: 'CAFÉS', item: 'Café leche',     price: 1.60, sales: 0, img: 'CDS/cafe-leche.jpeg' },
      { category: 'CAFÉS', item: 'Café americano', price: 1.50, sales: 0, img: 'CDS/cafe-americano.jpeg' },
      { category: 'ENTREPANS', item: 'Mini',       price: 2.50, sales: 0, img: 'images/mini.jpg' },
      { category: 'ENTREPANS', item: 'Normal',     price: 3.50, sales: 0, img: 'images/normal.jpg' },
      { category: 'ENTREPANS', item: 'Truita',     price: 3.00, sales: 0, img: 'CDS/truita.jpeg' },
      { category: 'ENTREPANS', item: 'Suplemento', price: 0.50, sales: 0, img: 'images/suplemento.jpg' },
      { category: 'ENTREPANS', item: 'Pastas',     price: 2.00, sales: 0, img: 'CDS/pasta.jpeg' },
      { category: 'CERVEZAS', item: 'Caña',        price: 1.60, sales: 0, img: 'images/cana.jpg' },
      { category: 'CERVEZAS', item: 'Caña grande', price: 2.50, sales: 0, img: 'images/cana_grande.jpg' },
      { category: 'CERVEZAS', item: 'Botella',     price: 2.50, sales: 0, img: 'CDS/botella.jpeg' },
      { category: 'CERVEZAS', item: 'Vino',        price: 1.50, sales: 0, img: 'CDS/wine.jpeg' },
      { category: 'REFRESCOS', item: 'Refrescos',  price: 2.00, sales: 0, img: 'CDS/refresco.jpeg' },
      { category: 'REFRESCOS', item: 'Batido',     price: 2.50, sales: 0, img: 'CDS/batido.jpeg' },
      { category: 'REFRESCOS', item: 'Agua',       price: 1.20, sales: 0, img: 'CDS/agua.jpeg' },
      { category: 'REFRESCOS', item: 'Chupito',    price: 2.00, sales: 0, img: 'CDS/chupito.jpeg' }
    ]);
  }

  // 🔁 Sync sales from invoices
  function syncSales() {
    const invoices = LS.get('invoices') || [];
    const inv = LS.get('inventory') || [];
    let salesMap = {};

    invoices.forEach(inv => {
      inv.items.forEach(it => {
        const key = (it.category || it.cat) + '|' + it.item;
        salesMap[key] = (salesMap[key] || 0) + it.qty;
      });
    });

    inv.forEach(item => {
      const key = (item.category || item.cat) + '|' + item.item;
      item.sales = salesMap[key] || 0;
    });

    LS.set('inventory', inv);
  }

  function drawInventory() {
    syncSales();
    const inv = LS.get('inventory') || [];
    invBody.innerHTML = '';
    inv.forEach((row, i) => {
      invBody.insertAdjacentHTML('beforeend', `
        <tr>
          <td>${row.category}</td>
          <td>${row.item}</td>
          <td>${row.price.toFixed(2)}</td>
          <td>${row.sales || 0}</td>
          <td><img src="${row.img || 'images/default.jpg'}" alt="" width="40"></td>
          <td>
            <button class="edit" data-i="${i}">✏️</button>
            <button class="del"  data-i="${i}">🗑</button>
          </td>
        </tr>`);
    });
  }

  drawInventory();

  invBody.addEventListener('click', e => {
    const i = e.target.dataset.i;
    if (i === undefined) return;
    const inv = LS.get('inventory') || [];

    if (e.target.classList.contains('edit')) {
      const r = inv[i];
      invForm.invCategory.value = r.category;
      invForm.invItem.value     = r.item;
      invForm.invPrice.value    = r.price;
      invForm.invImg.value      = r.img || '';
      invId.value = i;
    } else if (e.target.classList.contains('del')) {
      if (!confirm('Delete this item?')) return;
      inv.splice(i, 1);
      LS.set('inventory', inv);
      drawInventory();
    }
  });

  invForm.addEventListener('submit', e => {
    e.preventDefault();
    const inv = LS.get('inventory') || [];

    const obj = {
      category: invForm.invCategory.value.trim(),
      item: invForm.invItem.value.trim(),
      price: +invForm.invPrice.value,
      sales: invId.value ? inv[invId.value].sales || 0 : 0,
      img: invForm.invImg.value.trim() || 'images/default.jpg'
    };

    if (invId.value === '') inv.push(obj);
    else inv[invId.value] = obj;

    LS.set('inventory', inv);
    invForm.reset();
    invId.value = '';
    drawInventory();
  });

  document.getElementById('btnLogout').onclick = () => {
    SS.del('currentUser');
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
  };
  document.getElementById('btnInvoices').onclick = () => window.location.href = 'invoices.html';
  // --------- EMPLOYEE MANAGEMENT ---------
const empBody = document.querySelector('#employeesTable tbody');

function drawEmployees() {
  const users = LS.get('users') || [];
  empBody.innerHTML = '';
  users.filter(u => u.role !== 'owner').forEach(user => {
    empBody.insertAdjacentHTML('beforeend', `
      <tr>
        <td>${user.name || '—'}</td>
        <td>${user.user}</td>
        <td>${user.email || '—'}</td>
        <td>
          <button class="resetPwd" data-user="${user.user}">Reset Pwd</button>
          <button class="removeEmp" data-user="${user.user}">Remove</button>
        </td>
      </tr>
    `);
  });
}

drawEmployees();

// Handle reset & delete
empBody.addEventListener('click', e => {
  const uname = e.target.dataset.user;
  if (!uname) return;

  let users = LS.get('users') || [];
  const index = users.findIndex(u => u.user === uname);

  if (e.target.classList.contains('resetPwd')) {
    const newPass = prompt(`New password for ${uname}:`);
    if (!newPass) return;
    users[index].pass = newPass;
  } else if (e.target.classList.contains('removeEmp')) {
    if (!confirm(`Remove ${uname}?`)) return;
    users.splice(index, 1);
  }

  LS.set('users', users);
  drawEmployees();
});

});
