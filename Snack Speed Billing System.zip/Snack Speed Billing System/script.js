/*  Snack Speed – Login / Signup logic
    -------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {

  /* ---- tiny helpers ---- */
  const $$ = sel => document.querySelector(sel);
  const LS = {
    get : k      => JSON.parse(localStorage.getItem(k)  || 'null'),
    set : (k,v)  => localStorage.setItem(k, JSON.stringify(v)),
    del : k      => localStorage.removeItem(k)
  };
  const SS = {
    get : k      => JSON.parse(sessionStorage.getItem(k) || 'null'),
    set : (k,v)  => sessionStorage.setItem(k, JSON.stringify(v)),
    del : k      => sessionStorage.removeItem(k)
  };

  /* ---- bootstrap default owner ---- */
  const OWNER = { name:'Owner', user:'owner', pass:'owner123', role:'owner' };
  if (!LS.get('users')) LS.set('users', [OWNER]);

  /* ---- auto‑login if remembered ---- */
  const remembered = SS.get('currentUser') || LS.get('currentUser');
  if (remembered) return successLogin(remembered);

  /* ---- tab switch ---- */
  document.querySelectorAll('.tab').forEach(btn =>
    btn.addEventListener('click', () => {
      document.querySelector('.tab.active')?.classList.remove('active');
      btn.classList.add('active');

      document.querySelectorAll('.tab-content')
        .forEach(pane => pane.classList.add('hidden'));
      $$('#' + btn.dataset.tab).classList.remove('hidden');
    })
  );

  /* ---- password eye toggle ---- */
  document.querySelectorAll('.pw-toggle').forEach(btn =>
    btn.addEventListener('click', () => {
      const inp = $$('#' + btn.dataset.target);
      inp.type = inp.type === 'password' ? 'text' : 'password';
    })
  );

  /* ---- SIGN‑UP ---- */
  $$('#signupBtn').addEventListener('click', () => {
    const name  = $$('#signupName').value.trim(),
          user  = $$('#signupUser').value.trim(),
          email = $$('#signupEmail').value.trim(),
          pass  = $$('#signupPass').value.trim();

    if (!name || !user || !email || !pass)
      return alert('Fill in all fields.');

    const users = LS.get('users');
    if (users.find(u => u.user === user))
      return alert('Username already taken.');

    users.push({ name, user, email, pass, role:'employee' });
    LS.set('users', users);
    alert('Sign‑up successful! You can log in now.');

    // clear form & switch to Login tab
    ['signupName','signupUser','signupEmail','signupPass']
      .forEach(id => $$('#'+id).value='');
    document.querySelector('[data-tab="loginTab"]').click();
  });

  /* ---- LOGIN ---- */
  $$('#loginBtn').addEventListener('click', () => {
    const user = $$('#loginUser').value.trim(),
          pass = $$('#loginPass').value;

    if (!user || !pass) return alert('Enter both username and password.');

    const found = LS.get('users').find(u => u.user === user && u.pass === pass);
    if (!found) return alert('Invalid credentials.');

    const remember = $$('#rememberMe').checked;
    SS.set('currentUser', found);       // session always
    remember ? LS.set('currentUser',found) : LS.del('currentUser');

    successLogin(found);
  });

/* ---- post‑login redirect ---- */
function successLogin(user) {
  alert(`Welcome, ${user.name || user.user}!`);
  sessionStorage.setItem('currentUser', JSON.stringify(user));

  if (user.role === 'owner')  window.location.href = 'owner.html';
  else                        window.location.href = 'orders.html';
}


  /* ---------------- EMPLOYEE / OWNER REDIRECT ---------------- */
function successLogin(user) {
  alert(`Welcome, ${user.name || user.user}!`);

  // owner → owners panel (keep whatever you already use)
  if (user.role === 'owner') {
    window.location.href = 'owner.html';       // or your owners panel
    return;
  }

  // employee → orders page
  window.location.href = 'orders.html';
}

});
